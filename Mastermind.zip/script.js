/**
 This uses a 2d array representing the Mastermind board 
 board has 11 rows + 4 columns
 first row (row 0) is the secret code, generated at random
 remaining 10 rows are the player's guesses, from row 10 up to row 1 (i.e. up the board)
 There are 6 colour pegs to choose from, colours are stored in list of pegColours
 2d board array stores integers representing the peg colours
 2d array value of -1 means no peg
*/

let board = []
let pegColours = ['red', 'green', 'blue', 'yellow', 'black', 'white']
let playerRow = 10 // this is the row that the player is currently putting their pegs in
let currentPeg = 0 // this is the current peg colour, selected from the peg tray
let gridSize = 50
let guessedCorrectly = false


function generateSecretCode() {
  alert("You haven't written code to generate a secret code yet")
  /** TASK 3a
  the code should be stored in row 0 of the board
  for example this sets it to (blue black green white)
  board[0] = [2, 4, 1, 5]
  but you need to randomise it.
  The values refer to positions in the pegColours list, so must be integers and within the correct range
  */
  board[0] = [2, 4, 1, 5]
}

function newGame() {
  alert("You haven't written code to start a new game yet")
  /** TASK 3c
  need to call initGrid()
  reset the scoring (once you have implemented scoring)
  */

}
function checkGuess() {
  alert("You haven't written code to process the guess yet")
  
   /** TASK 4
  the player's guess needs to be compared to the secret code
  the correct score (white and black score pegs) must be generated

  if the player guesses correctly then the secret code will be revealed
  the draw function already handles displaying the secret code based on the value of guessedCorrectly
  
   */

  /** TASK 3b
   * the playerRow needs to be decreased by one so next guess goes in next row up
   * */
  guessedCorrectly = false
}

function drawScores() {
  /** TASK 4 c
  once you have figured out how to calculate the scores then they need to be drawn
  there is a gap between the board and the peg tray you could use for this
  this could be just as a couple of numbers (the white and the black scores)
  or as little pegs 
  */
  textSize(10)
  fill('brown')
  text("No score code yet\nYou need to write it", 4 * gridSize, 6 * gridSize, 2 * gridSize, 2 * gridSize)
}

/**
 * *******************************************
 * SHOULDN'T NEED TO MESS WITH CODE BELOW HERE
 * *******************************************
 */
function mouseClicked() {
  // use mouseX and mouseY to determine column and row clicked
  let column = floor(mouseX / gridSize)
  let row = floor(mouseY / gridSize)
  // if click was in the peg tray change peg colour
  if (column == 5) {
    setPegColour(row)
  } else {
    // else try placing a peg at this position
    placePeg(row, column)
  }
}

function setPegColour(r) {
  if (r < pegColours.length) {
    currentPeg = r
  }
}

function placePeg(row, column) {
  if (column >= 0 && column < 4 && row == playerRow) {
    // put currently selected peg colour in this position
    board[row][column] = currentPeg
  }
}

function initGrid() {
  //  initialise grid 
  board = []
  for (let r = 0; r < 11; r++) {
    // each row of the array is a 4 element array itself
    let row = new Array(4)
    // fill the array with -1s
    row.fill(-1)
    board.push(row)
  }
  playerRow = 10
  generateSecretCode()
}

function setup() {
  createCanvas(windowWidth, windowHeight)
  ellipseMode(CORNER)
  textAlign(CENTER, CENTER)
  textSize(30)
  initGrid()
}

function draw() {
  // draw the pale background
  fill('burlywood')
  rect(0, 0, 6 * gridSize, 11 * gridSize)
  // draw all the guesses so far, but not the secret code (unless have guessed correctly)
  for (let r = (guessedCorrectly ? 0 : 1); r < 11; r++) {
    for (let c = 0; c < 4; c++) {
      if (board[r][c] > -1) {
        fill(pegColours[board[r][c]])
      } else {
        fill(120)
      }
      ellipse(c * gridSize, r * gridSize, gridSize)
    }
  }
  // draw the peg tray
  for (let r = 0; r < pegColours.length; r++) {
    fill(pegColours[r])
    ellipse(5 * gridSize, r * gridSize, gridSize)
  }
  // highlight the current peg colour
  push()
  strokeWeight(6)
  stroke(pegColours[currentPeg])
  noFill()
  ellipse(5 * gridSize, currentPeg * gridSize, gridSize)
  pop()

  if (!guessedCorrectly) {
    // draw the title over the hidden code
    textAlign(CENTER, CENTER)
    textSize(30)
    fill('brown')
    text("Mastermind", gridSize * 2, gridSize / 2)
  }
  // draw the scores
  drawScores()
}