Background
==========
Mastermind is a logic game in which the player tries to guess a hidden pattern, consisting of 4 pegs selected from 6 different colours.

Each guess is scored according to how many pegs are the right colour in the right place, and how many are just the right colour.

In the example image (mastermind.jpg) you can make out the hidden code (blue green black red).
The player's first guess was (white blue yellow green) of which 2 pegs were the right colour in the wrong place (blue and green). Note the score is indicated by black and white scoring pegs. Black is for correct colour correct place, white is for correct colour wrong place.

The player's second guess (blue yellow red black) scored 2 white and 1 black, so 1 was correct colour correct place (blue), and 2 were correct colour wrong place (red and black)


Assignment
==========
Your task this week is to get the game working as well as you can.

The skeleton code provided sets up a blank board (2d array) and has code to detect clicks and draw the board.

TO START - google 'Mastermind game' and play some games to get used to how the scoring works

THEN - The key things that you need to do are:

o Write code the generates a random secret code
o Write code that starts a new game
o Figure out how you will calculate and store the score for each guess
o Write code that calculates the score for each guess
o Write code to display the score

That is pretty much it.
Beware - the scoring of a guess needs some thought


Advanced features
=================
There are all sorts of things you could add once you have the basic game fully functional.
For instance:
o Differing levels of difficulty based on:
  o range of peg colours
  o whether or not doubles (i.e. same colour peg repeated in the code) are allowed
  o number of pegs in the code
o Game score, based on total amount of time to guess the code successfully
o Online database of players and scores
o Player vs player online - given same code by server and have to solve it first to working
etc.
etc.



